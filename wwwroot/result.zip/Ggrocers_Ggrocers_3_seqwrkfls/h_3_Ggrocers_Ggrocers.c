
/******************************************************************************
*
* Copyright (C) 2014 Liverpool Data Research Associates
*
* SHLayout File : .\c\cshlayout.dat
* Language      : C
* Version       : 9.4.6
*
* This is the default shlayout file for generating C driver programs.
*
* The shlayout file contains source code which will be included at various
* points within the sequencer and harness driver programs.
*
* The code contained within the shlayout may be modified to suit the
* requirements of the current host or target system.
*
* User Modification History
* =========================
*
* Date      Name        Description
* ====      ====        ===========
*
*
*
*
*
******************************************************************************/

/*
 *
 * Harness Program
 *
 * Sequence Name : Ggrocers
 *
 * Sequence File List:
 * D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 *
 * Existing Test Cases ( ID Procedure File )
 * 1 initialise_customer D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 2 customer_cash_injection D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 3 get_number_of_pence D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 4 convert_pence D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 5 buy_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 6 buy_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 7 buy_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 8 buy_fruit_ex D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 9 buy_fruit_ex D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 10 change_fruit_price D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 11 calculate_cheapest_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 12 buy_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 13 fruit_cheaper_than D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 14 get_favourite_fruit_price D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 15 how_many_favourite_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 16 write_price_list D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 17 buy_healthiest D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 18 buy_healthiest D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 19 char_to_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * 20 how_many_favourite_fruit D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 *
 * Program created on Sat Oct 31 2020 at 10:55:53
 *
 */

/*
 * To include source code before the declaration section
 * ****7 Driver declarations in D:\LDRA_Toolsuite_CEE_9.4.6\c\cshlayout.dat
 * check the "Include Source Code Before Driver or Host Declarations" box
 * in the "S & H Generation" tab of the "TBrun Options" dialog.
 *
 * To set this as the default for all sequences, set the
 * profile string "TBRUN_INCLUDE_ON_TOP=TRUE" in Testbed.ini
 * prior to invoking TBrun.
 */
/* ****7 Driver declarations */

#include <stdio.h>
#ifdef ldra_qq_no_constants
#define const
#endif

void ldra_qq_set_stub_hit_count (int *last_tc,int *this_count,int *total_count);
void ldra_qq_stub_start (char *ldra_qq_pname);
void ldra_qq_stub_end (int ldra_qq_stub_valid,
                       char *ldra_qq_stub_message);
#if defined ldra_qq_nodotdotdot
void ldra_qq_test_comment (char *fmt,int start,int new_line);
#else
void ldra_qq_test_comment (char *fmt,...);
#endif
void ldra_qq_stub_start_comment (char *ldra_qq_procname);
void ldra_qq_stub_end_comment (char *ldra_qq_procname);
void ldra_qq_stub_invalid_test (char **ldra_qq_stub_mess,int *ldra_qq_stub_val);

void ldra_qq_set_stub_smho (int *ldra_qq_matrix,int *ldra_qq_index,int ldra_qq_max,
                            int ldra_qq_stub_id,char *ldra_qq_stub_name,int ldra_qq_hc);

const int ldra_qq_smho_unexecuted = 0;
const int ldra_qq_smho_executed_correct = 1;
const int ldra_qq_smho_executed_incorrect = -1;
const int ldra_qq_smho_hc_terminator = -10;
const int ldra_qq_smho_tc_terminator = -100;


/* ****1 Globals for output */

#include <stdarg.h>
FILE *testbed_out;


char testbed_buff[512];

void ldra_qq_tbrun_output (char *fmt,...);
#define ldra_qq_tbrun
#define ldra_qq_tbrun_driver
int ldra_qq_history_in_target = 0;
char *ldra_qq_sequence_name = "Ggrocers";
int ldra_qq_quiet_stubs = 0;
int ldra_qq_test_case_number = 0;
int ldra_qq_last_test_case = -1;
int ldra_qq_tc_iterator = -1;
int ldra_qq_tc_repeater = -1;
int ldra_qq_module_number = 0;
char *ldra_qq_module_name = NULL;
int ldra_qq_procedure_number = 0;
char *ldra_qq_procedure_name = NULL;
int ldra_qq_number_of_existing_tcs = 20;
int ldra_qq_in_existing_test_case = 0;
int ldra_qq_in_new_test_case = 0;
char *ldra_qq_action_code = "";
int inszt_confirm_enabled = 0;

/*
 * Pre-include code will be placed here
 * this code is located at global scope and should consist of
 * declarations, preprocessor directives (e.g. #include) or procedures
 */
#define main tbrun_qq_no_main_3
#ifdef _MSC_VER
#pragma message (" => Compiling source: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c started")
#endif
#include "D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c"
#ifdef _MSC_VER
#pragma message (" => Compiling source: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c finished")
#endif
#undef main
/*
 * Post-include code will be placed here
 * this code is located at global scope and should consist of
 * declarations, preprocessor directives (e.g. #include) or procedures
 */
/*
 * To include tbrunlib.h before the source code
 * set the profile_string "TBRUNLIB_BEFORE_SOURCE=TRUE"
 * in Testbed.ini prior to invoking TBrun
 */
#include "D:\LDRA_Toolsuite_CEE_9.4.6\c\ctbrunlib.h"

/*
 * Declarations for user globals will be placed here
 */

/* ****20 Stub utilities */

struct ldra_qq_stub_hit_count
{
  int last_tc;
  int this_count;
  int total_count;
};

struct ldra_qq_stub_hit_order
{
  int total;
  int index;
  /*
   * 0 = no error
   * 1 = stub hit order total exceeded
   * 2 = incorrect stub hit found
   */
  int error_code;
};

void ldra_qq_set_stub_smho (int *ldra_qq_matrix,int *ldra_qq_index,int ldra_qq_max,
                            int ldra_qq_stub_id,char *ldra_qq_stub_name,int ldra_qq_hc)
{
  char ecc = '\0';
  int ind;
  int hc;
#if defined ldra_qq_nodotdotdot
  char buff[50];
#endif

  if (ldra_qq_quiet_stubs == 0)
  {
    do
    {
      if (*ldra_qq_index >= ldra_qq_max ||
          ldra_qq_matrix[*ldra_qq_index] == ldra_qq_smho_tc_terminator)
      {
        /* stub hit order total exceeded */
        ecc = 'X';
      }
      else if (ldra_qq_matrix[*ldra_qq_index] == ldra_qq_hc)
      {
        /* hit count found - look for stub id */
        hc = *ldra_qq_index + 1;
        ind = hc + 1;
        while (ecc == '\0' && ldra_qq_matrix[ind] != ldra_qq_smho_hc_terminator)
        {
          if (ldra_qq_matrix[ind] == ldra_qq_stub_id)
          {
            ecc = 'P';
            ldra_qq_matrix[hc] = 1;
          }
          ind++;
        }
        if (ecc == '\0')
        {
          ecc = 'F';
          ldra_qq_matrix[hc] = -1;
        }
      }
      else if (ldra_qq_matrix[*ldra_qq_index] < ldra_qq_hc)
      {
        /* move on to the next hit */
        do
        {
          (*ldra_qq_index)++;
        } while (ldra_qq_matrix[*ldra_qq_index] != ldra_qq_smho_hc_terminator);
        (*ldra_qq_index)++;
      }
      else
      {
        /* not specified for this hit */
        ecc = 'U';
      }
    } while (ecc == '\0');

#if defined ldra_qq_nodotdotdot
    ldra_qq_tbrun_output ("Y ",1,0);

    buff[0] = ecc;
    buff[1] = ' ';
    buff[2] = '\0';
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_stub_id);
    ldra_qq_tbrun_output (buff,0,0);

    ldra_qq_tbrun_output (ldra_qq_stub_name,0,1);
#else
    ldra_qq_tbrun_output ("Y %c %d %s\n",ecc,ldra_qq_stub_id,ldra_qq_stub_name);
#endif
  }
} /* end of ldra_qq_set_stub_smho */

int ldra_qq_confirm_smho (int *ldra_qq_matrix,int ldra_qq_ho_total)
{
  int ret = 1;
  int ldra_qq_ho_expected = 0;
  int ec = 0;
  char pf = 'P';
#if defined ldra_qq_nodotdotdot
  char buff[50];
#endif

  if (ldra_qq_quiet_stubs == 0)
  {
    while (*ldra_qq_matrix != ldra_qq_smho_tc_terminator)
    {
      ldra_qq_ho_expected = *ldra_qq_matrix;
      ldra_qq_matrix++;
      if (*ldra_qq_matrix == ldra_qq_smho_executed_incorrect)
      {
        ec |= 2;
        pf = 'F';
      }
      while (*ldra_qq_matrix != ldra_qq_smho_hc_terminator)
      {
        ldra_qq_matrix++;
      }
      ldra_qq_matrix++;
    }

    if (ldra_qq_ho_expected < ldra_qq_ho_total)
    {
      ec |= 1;
      pf = 'F';
    }
    else if (ldra_qq_ho_expected > ldra_qq_ho_total)
    {
      ec |= 4;
      pf = 'F';
    }

#if defined ldra_qq_nodotdotdot
    ldra_qq_tbrun_output ("Z ",1,0);

    buff[0] = pf;
    buff[1] = ' ';
    buff[2] = '\0';
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_ho_total);
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_ho_expected);
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ec);
    ldra_qq_tbrun_output (buff,0,1);
#else
    ldra_qq_tbrun_output ("Z %c %d %d %d\n",pf,ldra_qq_ho_total,
                          ldra_qq_ho_expected,ec);
#endif
  }

  return ret;
} /* end of ldra_qq_confirm_smho */

int ldra_qq_set_stub_hit_order (struct ldra_qq_stub_hit_order *ldra_qq_stub_ho,
                                int *ldra_qq_ho_arr,char *ldra_qq_ho_name,
                                int ldra_qq_ho_code)
{
  int ret = -1;
  int ec = 0;
  char ecc = 'P';
#if defined ldra_qq_nodotdotdot
  char buff[50];
#endif

  if (ldra_qq_quiet_stubs == 0)
  {
    ldra_qq_stub_ho->index = ldra_qq_stub_ho->index + 1;
    if (ldra_qq_stub_ho->index < ldra_qq_stub_ho->total)
    {
      if (ldra_qq_ho_arr[ldra_qq_stub_ho->index] == ldra_qq_ho_code)
      {
        /* return the index of the verified call */
        ret = ldra_qq_stub_ho->index;
      }
      else
      {
        /* incorrect stub hit found */
        ec = 2;
        ecc = 'F';
      }
    }
    else
    {
      /* stub hit order total exceeded */
      ec = 1;
      ecc = 'X';
    }

    if (ldra_qq_stub_ho->error_code == 0 && ec != 0)
    {
      ldra_qq_stub_ho->error_code = ec;
    }

#if defined ldra_qq_nodotdotdot
    ldra_qq_tbrun_output ("Y ",1,0);

    buff[0] = ecc;
    buff[1] = ' ';
    buff[2] = '\0';
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_stub_ho->index);
    ldra_qq_tbrun_output (buff,0,0);

    ldra_qq_tbrun_output (ldra_qq_ho_name,0,1);
#else
    ldra_qq_tbrun_output ("Y %c %d %s\n",ecc,
                          ldra_qq_stub_ho->index,
                          ldra_qq_ho_name);
#endif
  }

  return ret;
} /* end of ldra_qq_set_stub_hit_order */

int ldra_qq_confirm_stub_hit_order (struct ldra_qq_stub_hit_order ldra_qq_stub_ho)
{
  int ret = 1;
  char pf = 'P';
#if defined ldra_qq_nodotdotdot
  char buff[50];
#endif

  if (ldra_qq_quiet_stubs == 0)
  {
    if (ldra_qq_stub_ho.error_code != 0)
    {
      pf = 'F';
      ret = 0;
    }
    else
    {
      if ((ldra_qq_stub_ho.index + 1) != ldra_qq_stub_ho.total)
      {
        pf = 'F';
        ret = 0;
      }
    }

#if defined ldra_qq_nodotdotdot
    ldra_qq_tbrun_output ("Z ",1,0);

    buff[0] = pf;
    buff[1] = ' ';
    buff[2] = '\0';
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_stub_ho.total);
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_stub_ho.index);
    ldra_qq_tbrun_output (buff,0,0);

    sprintf (buff,"%d ",ldra_qq_stub_ho.error_code);
    ldra_qq_tbrun_output (buff,0,1);
#else
    ldra_qq_tbrun_output ("Z %c %d %d %d\n",pf,ldra_qq_stub_ho.total,
                          ldra_qq_stub_ho.index,ldra_qq_stub_ho.error_code);
#endif
  }

  return ret;
} /* end of ldra_qq_confirm_stub_hit_order */

void ldra_qq_set_stub_hit_count (int *last_tc,int *this_count,int *total_count)
{
  if (*last_tc != ldra_qq_test_case_number)
  {
  /*
   * the test case has changed from the last hit -
   * so change the test case number and reset the hit count
   */
    *last_tc = ldra_qq_test_case_number;
    *this_count = 0;
  }
  (*this_count)++;
  (*total_count)++;
} /* end of ldra_qq_set_stub_hit_count */

void ldra_qq_stub_start (char *ldra_qq_pname)
{
  if (ldra_qq_quiet_stubs == 0)
  {
#if defined ldra_qq_nodotdotdot
    ldra_qq_tbrun_output ("P S ",1,0);
    ldra_qq_tbrun_output (ldra_qq_pname,0,1);
#else
    ldra_qq_tbrun_output ("P S %s\n",ldra_qq_pname);
#endif
  }
} /* end of ldra_qq_stub_start */

void ldra_qq_stub_end (int ldra_qq_stub_valid,
                       char *ldra_qq_stub_message)
{
  if (ldra_qq_quiet_stubs == 0)
  {
#if defined ldra_qq_nodotdotdot
    if (ldra_qq_stub_message == (char*)(0))
    {
      if (ldra_qq_stub_valid)
      {
        ldra_qq_tbrun_output ("P E V",1,1);
      }
      else
      {
        ldra_qq_tbrun_output ("P E F",1,1);
      }
    }
    else
    {
      if (ldra_qq_stub_valid)
      {
        ldra_qq_tbrun_output ("P E V ",1,0);
        ldra_qq_tbrun_output (ldra_qq_stub_message,0,1);
      }
      else
      {
        ldra_qq_tbrun_output ("P E F ",1,0);
        ldra_qq_tbrun_output (ldra_qq_stub_message,0,1);
      }
    }
#else
    if (ldra_qq_stub_message == (char*)(0))
    {
      if (ldra_qq_stub_valid)
      {
        ldra_qq_tbrun_output ("P E V\n");
      }
      else
      {
        ldra_qq_tbrun_output ("P E F\n");
      }
    }
    else
    {
      if (ldra_qq_stub_valid)
      {
        ldra_qq_tbrun_output ("P E V %s\n",ldra_qq_stub_message);
      }
      else
      {
        ldra_qq_tbrun_output ("P E F %s\n",ldra_qq_stub_message);
      }
    }
#endif
  }
} /* end of ldra_qq_stub_end */

#if defined ldra_qq_nodotdotdot
void ldra_qq_test_comment (char *fmt,int start,int new_line)
#else
void ldra_qq_test_comment (char *fmt,...)
#endif
{
  if (ldra_qq_quiet_stubs == 0)
  {
    if (fmt == (char*)(0))
    {
#if defined ldra_qq_nodotdotdot
      if (start)
      {
        ldra_qq_tbrun_output ("M ",1,0);
      }
      ldra_qq_tbrun_output ("",0,new_line);
#else
      ldra_qq_tbrun_output ("M\n");
#endif
    }
    else
    {
#if defined ldra_qq_nodotdotdot
      if (start)
      {
        ldra_qq_tbrun_output ("M ",1,0);
      }
      ldra_qq_tbrun_output (fmt,0,new_line);
#else
      char buff[1024] = {0};
      va_list va;

      va_start (va,fmt);
      vsprintf (buff,fmt,va);
      va_end (va);
      ldra_qq_tbrun_output ("M %s\n",buff);
#endif
    }
  }
} /* end of ldra_qq_test_comment */

void ldra_qq_stub_start_comment (char *ldra_qq_procname)
{
  if (ldra_qq_quiet_stubs == 0)
  {
#if defined ldra_qq_nodotdotdot
    ldra_qq_test_comment ("***",1,1);
#else
    ldra_qq_test_comment ("***");
#endif
    if (ldra_qq_procname == (char*)(0))
    {
#if defined ldra_qq_nodotdotdot
      ldra_qq_test_comment ("*** Starting Stub",1,1);
#else
      ldra_qq_test_comment ("*** Starting Stub");
#endif
    }
    else
    {
#if defined ldra_qq_nodotdotdot
      ldra_qq_test_comment ("*** Starting Stub : ",1,0);
      ldra_qq_test_comment (ldra_qq_procname,0,1);
#else
      ldra_qq_test_comment ("*** Starting Stub : %s",ldra_qq_procname);
#endif
    }
#if defined ldra_qq_nodotdotdot
    ldra_qq_test_comment ("***",1,1);
#else
    ldra_qq_test_comment ("***");
#endif
  }
} /* end of ldra_qq_stub_start_comment */

void ldra_qq_stub_end_comment (char *ldra_qq_procname)
{
  if (ldra_qq_quiet_stubs == 0)
  {
#if defined ldra_qq_nodotdotdot
    ldra_qq_test_comment ("###",1,1);
#else
    ldra_qq_test_comment ("###");
#endif
    if (ldra_qq_procname == (char*)(0))
    {
#if defined ldra_qq_nodotdotdot
      ldra_qq_test_comment ("### Ending Stub",1,1);
#else
      ldra_qq_test_comment ("### Ending Stub");
#endif
    }
    else
    {
#if defined ldra_qq_nodotdotdot
      ldra_qq_test_comment ("### Ending Stub : ",1,0);
      ldra_qq_test_comment (ldra_qq_procname,0,1);
#else
      ldra_qq_test_comment ("### Ending Stub : %s",ldra_qq_procname);
#endif
    }
#if defined ldra_qq_nodotdotdot
    ldra_qq_test_comment ("###",1,1);
#else
    ldra_qq_test_comment ("###");
#endif
  }
} /* end of ldra_qq_stub_end_comment */

void ldra_qq_stub_invalid_test (char **ldra_qq_stub_mess,int *ldra_qq_stub_val)
{
  *ldra_qq_stub_mess = "Test Failed";
  *ldra_qq_stub_val = 0;
} /* end of ldra_qq_stub_invalid_test */

void ldra_qq_stub_hit_count_test (struct ldra_qq_stub_hit_count ldra_qq_stub_hc,
                                  int tcstyle,char *name,int style,
                                  int expected)
{
  int actual = ldra_qq_stub_hc.total_count;
  char tcseq = 'S';
  char pf = 'V';
#if defined ldra_qq_nodotdotdot
  char buff[50];
#endif

  if (ldra_qq_quiet_stubs == 0)
  {
    if (style == 1 || style == 2 || style == 3)
    {
      if (tcstyle)
      {
        tcseq = 'T';
        actual = ldra_qq_stub_hc.this_count;
      }
      switch (style)
      {
        case 1:
          /* fails if executed */
          if (actual > 0)
          {
            pf = 'F';
          }
          break;
        case 2:
          /* fails if not executed */
          if (actual < 1)
          {
            pf = 'F';
          }
          break;
        case 3:
          /* fails if not executed correct number of times */
          if (actual != expected)
          {
            pf = 'F';
          }
          break;
      }

#if defined ldra_qq_nodotdotdot
      ldra_qq_tbrun_output ("H ",1,0);

      buff[0] = tcseq;
      buff[1] = ' ';
      buff[2] = '\0';
      ldra_qq_tbrun_output (buff,0,0);

      ldra_qq_tbrun_output (name,0,0);

      sprintf (buff," %d ",style);
      ldra_qq_tbrun_output (buff,0,0);

      sprintf (buff,"%d ",expected);
      ldra_qq_tbrun_output (buff,0,0);

      sprintf (buff,"%d ",actual);
      ldra_qq_tbrun_output (buff,0,0);

      buff[0] = pf;
      buff[1] = ' ';
      buff[2] = '\0';
      ldra_qq_tbrun_output (buff,0,1);
#else
      ldra_qq_tbrun_output ("H %c %s %d %d %d %c\n",
                            tcseq,name,style,expected,actual,pf);
#endif
    }
  }
} /* end of ldra_qq_stub_hit_count_test */

void ldra_qq_stub_hit_count_comment (struct ldra_qq_stub_hit_count ldra_qq_stub_hc)
{
  if (ldra_qq_quiet_stubs == 0)
  {
#if defined ldra_qq_nodotdotdot
    char buff[50];

    sprintf (buff,"%d",ldra_qq_stub_hc.this_count);
    ldra_qq_test_comment ("Test Case Hit Count : ",1,0);
    ldra_qq_test_comment (buff,0,1);

    sprintf (buff,"%d",ldra_qq_stub_hc.total_count);
    ldra_qq_test_comment ("Sequence Hit Count : ",1,0);
    ldra_qq_test_comment (buff,0,1);
#else
    ldra_qq_test_comment ("Test Case Hit Count : %d",ldra_qq_stub_hc.this_count);
    ldra_qq_test_comment ("Sequence Hit Count  : %d",ldra_qq_stub_hc.total_count);
#endif
  }
} /* end of ldra_qq_stub_hit_count_comment */

/* ****9 Action code comparison routine */

#define ldra_qq_action_code_compare(A) ldra_qq_strcmp (A,ldra_qq_action_code) == 0


/*
 * Return declaration(s) for existing test case(s)
 */
double tbrun_qq_tc2_return;
int tbrun_qq_tc3_return;
double tbrun_qq_tc4_return;
int tbrun_qq_tc5_return;
int tbrun_qq_tc6_return;
int tbrun_qq_tc7_return;
int tbrun_qq_tc8_return;
int tbrun_qq_tc9_return;
double tbrun_qq_tc10_return;
fruit tbrun_qq_tc11_return;
int tbrun_qq_tc12_return;
int tbrun_qq_tc13_return;
double tbrun_qq_tc14_return;
int tbrun_qq_tc15_return;
double tbrun_qq_tc16_return;
int tbrun_qq_tc17_return;
int tbrun_qq_tc18_return;
int tbrun_qq_tc19_return;
int tbrun_qq_tc20_return;

/*
 *
 * Conversion routine converts the fruit (typedef) enumeration
 * into ASCII text to be outputted by the
 * sequencer and harness programs
 *
 * To add the enum keyword from the parameter declaration, set the radio button
 * "Specify Enumeration Parameters as" to "enum Enumeration_Tag"
 * in the TBrun Options dialog prior to generating the sequencer or harness program.
 *
 */
int ldra_enum_t_fruit_convert_3 (fruit enum_name,char *res)
{
  int ldra_qq_enum_valid = 0;
  int ldra_qq_i = 0;
  const fruit ldra_qq_enum_array[5] = {
    apple,
    orange,
    grapes,
    pear,
    melon};
  char * ldra_qq_enum_str_array[5] = {
    "apple",
    "orange",
    "grapes",
    "pear",
    "melon"};

  while (ldra_qq_i < 5 && ldra_qq_enum_valid == 0)
  {
    if (enum_name == ldra_qq_enum_array[ldra_qq_i])
    {
#ifdef _ldra_qq_strcpy_
      ldra_qq_strcpy (res,ldra_qq_enum_str_array[ldra_qq_i]);
#else
      strcpy (res,ldra_qq_enum_str_array[ldra_qq_i]);
#endif
      ldra_qq_enum_valid = 1;
    }
    ldra_qq_i++;
  }

  if (ldra_qq_enum_valid == 0)
  {
#ifdef _ldra_qq_strcpy_
    ldra_qq_strcpy (res,"INVALID ENUM VALUE");
#else
    strcpy (res,"INVALID ENUM VALUE");
#endif
  }

  return ldra_qq_enum_valid;
} /* end of typedef enum fruit convert */

static int ldra_qq_dtop_fruit (fruit expected_value,fruit actual_value,char * name,
                               char * svalue,char df,int convert,int compare,
                               int convert_ok,char * expstr)
{
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
  char ldra_qq_df_str[3];
  int ldra_qq_saved_history_in_target = ldra_qq_history_in_target;
  testbed_buff[0] = '\0';
  ldra_qq_df_str[0] = df;
  ldra_qq_df_str[1] = ' ';
  ldra_qq_df_str[2] = '\0';
    if (convert == 1)
    {
      ldra_qq_variable_converted = ldra_enum_t_fruit_convert_3 (actual_value,testbed_buff);
    }
  if (ldra_qq_var_exception_raised == 1)
  {
    printf (" Output for %s is *** Suspended *** \n",name);
    ldra_qq_tbrun_output ("O X %c %s\n",df,name);
    ldra_qq_variable_passed = 0;
  }
  else
  {
    printf (" Output for %s = %s \n",name,testbed_buff);
    if (convert > 0)
    {
      ldra_qq_tbrun_output ("O V %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    else
    {
      ldra_qq_tbrun_output ("O C %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    if (ldra_qq_variable_converted == 1)
    {
        ldra_qq_variable_passed = 0;
        if (compare == 1)
        {
          if (expected_value != actual_value)
          {
            ldra_qq_variable_passed = 0;
          }
          else
          {
            ldra_qq_variable_passed = 1;
          }
        }
    }
    else
    {
      if (convert_ok == 0)
      {
        ldra_qq_variable_passed = ldra_qq_string_compare (expstr,testbed_buff);
      }
      else
      {
        ldra_qq_variable_passed = 0;
      }
    }
    if (ldra_qq_variable_passed == 1)
    {
      ldra_qq_tbrun_output ("P ");
      printf (" PASS\n");
    }
    else
    {
      ldra_qq_tbrun_output ("F ");
      if (convert > 0)
      {
        printf (" FAIL: expecting %s\n",svalue);
      }
      else
      {
        printf (" FAIL\n");
      }
    }
    ldra_qq_history_in_target = 0;
    if (ldra_qq_variable_converted == 1)
    {
      ldra_qq_tbrun_output ("V");
    }
    else
    {
      ldra_qq_tbrun_output ("F");
      printf ("   Unable to convert value\n");
    }
    if (convert > 0)
    {
      ldra_qq_tbrun_output (" ");
      ldra_qq_tbrun_output (testbed_buff);
    }
    ldra_qq_tbrun_output ("\n");
    ldra_qq_history_in_target = ldra_qq_saved_history_in_target;
  }
  return ldra_qq_variable_passed;
} /* end of ldra_qq_dtop_fruit */

static int ldra_qq_dtop_double (double expected_value,double actual_value,char * name,
                                char * svalue,char df,int convert,int compare,
                                int convert_ok,char * expstr)
{
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
  char ldra_qq_df_str[3];
  int ldra_qq_saved_history_in_target = ldra_qq_history_in_target;
  testbed_buff[0] = '\0';
  ldra_qq_df_str[0] = df;
  ldra_qq_df_str[1] = ' ';
  ldra_qq_df_str[2] = '\0';
    if (convert == 1)
    {
      ldra_qq_variable_converted = ldra_qq_double_convert (actual_value,testbed_buff);
    }
  if (ldra_qq_var_exception_raised == 1)
  {
    printf (" Output for %s is *** Suspended *** \n",name);
    ldra_qq_tbrun_output ("O X %c %s\n",df,name);
    ldra_qq_variable_passed = 0;
  }
  else
  {
    printf (" Output for %s = %s \n",name,testbed_buff);
    if (convert > 0)
    {
      ldra_qq_tbrun_output ("O V %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    else
    {
      ldra_qq_tbrun_output ("O C %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    if (ldra_qq_variable_converted == 1)
    {
        ldra_qq_variable_passed = 0;
        if (compare == 1)
        {
          if (!((expected_value >= (actual_value-0.000001)) && (expected_value <= (actual_value+0.000001))))
          {
            ldra_qq_variable_passed = 0;
          }
          else
          {
            if ((expected_value >= 0 && actual_value >= 0) ||
                (expected_value <= 0 && actual_value <= 0))
            {
              ldra_qq_variable_passed = 1;
            }
            else
            {
              ldra_qq_variable_passed = 0;
            }
          }
        }
    }
    else
    {
      if (convert_ok == 0)
      {
        ldra_qq_variable_passed = ldra_qq_string_compare (expstr,testbed_buff);
      }
      else
      {
        ldra_qq_variable_passed = 0;
      }
    }
    if (ldra_qq_variable_passed == 1)
    {
      ldra_qq_tbrun_output ("P ");
      printf (" PASS\n");
    }
    else
    {
      ldra_qq_tbrun_output ("F ");
      if (convert > 0)
      {
        printf (" FAIL: expecting %s\n",svalue);
      }
      else
      {
        printf (" FAIL\n");
      }
    }
    ldra_qq_history_in_target = 0;
    if (ldra_qq_variable_converted == 1)
    {
      ldra_qq_tbrun_output ("V");
    }
    else
    {
      ldra_qq_tbrun_output ("F");
      printf ("   Unable to convert value\n");
    }
    if (convert > 0)
    {
      ldra_qq_tbrun_output (" ");
      ldra_qq_tbrun_output (testbed_buff);
    }
    ldra_qq_tbrun_output ("\n");
    ldra_qq_history_in_target = ldra_qq_saved_history_in_target;
  }
  return ldra_qq_variable_passed;
} /* end of ldra_qq_dtop_double */

static int ldra_qq_dtop_int (int expected_value,int actual_value,char * name,
                             char * svalue,char df,int convert,int compare,
                             int convert_ok,char * expstr)
{
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
  char ldra_qq_df_str[3];
  int ldra_qq_saved_history_in_target = ldra_qq_history_in_target;
  testbed_buff[0] = '\0';
  ldra_qq_df_str[0] = df;
  ldra_qq_df_str[1] = ' ';
  ldra_qq_df_str[2] = '\0';
    if (convert == 1)
    {
      sprintf (testbed_buff,"%d",actual_value);
    }
  if (ldra_qq_var_exception_raised == 1)
  {
    printf (" Output for %s is *** Suspended *** \n",name);
    ldra_qq_tbrun_output ("O X %c %s\n",df,name);
    ldra_qq_variable_passed = 0;
  }
  else
  {
    printf (" Output for %s = %s \n",name,testbed_buff);
    if (convert > 0)
    {
      ldra_qq_tbrun_output ("O V %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    else
    {
      ldra_qq_tbrun_output ("O C %c %s\n",df,name);
      ldra_qq_tbrun_output ("E %s\n",svalue);
    }
    if (ldra_qq_variable_converted == 1)
    {
        ldra_qq_variable_passed = 0;
        if (compare == 1)
        {
          if (expected_value != actual_value)
          {
            ldra_qq_variable_passed = 0;
          }
          else
          {
            ldra_qq_variable_passed = 1;
          }
        }
    }
    else
    {
      if (convert_ok == 0)
      {
        ldra_qq_variable_passed = ldra_qq_string_compare (expstr,testbed_buff);
      }
      else
      {
        ldra_qq_variable_passed = 0;
      }
    }
    if (ldra_qq_variable_passed == 1)
    {
      ldra_qq_tbrun_output ("P ");
      printf (" PASS\n");
    }
    else
    {
      ldra_qq_tbrun_output ("F ");
      if (convert > 0)
      {
        printf (" FAIL: expecting %s\n",svalue);
      }
      else
      {
        printf (" FAIL\n");
      }
    }
    ldra_qq_history_in_target = 0;
    if (ldra_qq_variable_converted == 1)
    {
      ldra_qq_tbrun_output ("V");
    }
    else
    {
      ldra_qq_tbrun_output ("F");
      printf ("   Unable to convert value\n");
    }
    if (convert > 0)
    {
      ldra_qq_tbrun_output (" ");
      ldra_qq_tbrun_output (testbed_buff);
    }
    ldra_qq_tbrun_output ("\n");
    ldra_qq_history_in_target = ldra_qq_saved_history_in_target;
  }
  return ldra_qq_variable_passed;
} /* end of ldra_qq_dtop_int */

/*
 * Prototypes for existing test cases
 */
int ldra_qq_execute_test_case_1 ();
int ldra_qq_execute_test_case_2 ();
int ldra_qq_execute_test_case_3 ();
int ldra_qq_execute_test_case_4 ();
int ldra_qq_execute_test_case_5 ();
int ldra_qq_execute_test_case_6 ();
int ldra_qq_execute_test_case_7 ();
int ldra_qq_execute_test_case_8 ();
int ldra_qq_execute_test_case_9 ();
int ldra_qq_execute_test_case_10 ();
int ldra_qq_execute_test_case_11 ();
int ldra_qq_execute_test_case_12 ();
int ldra_qq_execute_test_case_13 ();
int ldra_qq_execute_test_case_14 ();
int ldra_qq_execute_test_case_15 ();
int ldra_qq_execute_test_case_16 ();
int ldra_qq_execute_test_case_17 ();
int ldra_qq_execute_test_case_18 ();
int ldra_qq_execute_test_case_19 ();
int ldra_qq_execute_test_case_20 ();

void ldra_qq_sequence_init ()
{
/*
 * Sequence initialisation code will be placed here
 * Variables declared in this section do not have global scope
 */
} /* end of ldra_qq_sequence_init */

void ldra_qq_sequence_cleanup ()
{
/*
 * Sequence initialisation code will be placed here
 * Variables declared in this section do not have global scope
 */
} /* end of ldra_qq_sequence_cleanup */

void ldra_qq_etc_completion ()
{
/* ****3 Existing test case completion */

  fclose (testbed_out);

} /* end of ldra_qq_etc_completion */

int ldra_qq_etc_initialisation ()
{
/* ****2 Existing test case initialisation */

  if (ldra_qq_history_in_target)
  {
    testbed_out = fopen ("Ggrocers.top","w");
  }
  else
  {
    testbed_out = fopen ("D:\\LDRA_Workarea_CEE_9.4.6\\tbwrkfls\\Ggrocers_Ggrocers_3_seqwrkfls\\Ggrocers.hop","w");
  }
  return testbed_out != NULL;

} /* end of ldra_qq_etc_initialisation */

void ldra_qq_ntc_completion ()
{
/* ****5 New test case completion */

  fclose (testbed_out);

} /* end of ldra_qq_ntc_completion */

int ldra_qq_ntc_initialisation ()
{
/* ****4 New test case initialisation */

  if (ldra_qq_history_in_target)
  {
    if (ldra_qq_number_of_existing_tcs > 0)
    {
      testbed_out = fopen ("Ggrocers.top","a");
    }
    else
    {
      testbed_out = fopen ("Ggrocers.top","w");
    }
  }
  else
  {
    testbed_out = fopen ("D:\\LDRA_Workarea_CEE_9.4.6\\tbwrkfls\\Ggrocers_Ggrocers_3_seqwrkfls\\Ggrocers.sop","w");
  }
  return testbed_out != NULL;

} /* end of ldra_qq_ntc_initialisation */

void ldra_qq_tbrun_output (char *fmt,...)
{
/* ****6 TBrun output routine */

#if defined ldra_qq_nodotdotdot
  char *s = fmt;

  if (ldra_qq_history_in_target && start)
  {
    if (s[0] != 10)
    {
      if (ldra_qq_in_new_test_case)
      {
        fprintf (testbed_out,"S ");
      }
      else
      {
        fprintf (testbed_out,"H ");
      }
    }
  }

  while (*s != '\0')
  {
    fputc (*s,testbed_out);
    s++;
  }

  if (new_line)
  {
    fprintf (testbed_out,"\n");
  }
#else
  char buff[1024] = {0};
  va_list va;
  va_start (va,fmt);
  vsprintf (buff,fmt,va);
  va_end (va);
  if (ldra_qq_history_in_target)
  {
    if (buff[0] != 10)
    {
      if (ldra_qq_in_new_test_case)
      {
        fprintf (testbed_out,"S ");
      }
      else
      {
        fprintf (testbed_out,"H ");
      }
    }
  }
  fprintf (testbed_out,buff);
#endif
    fflush (testbed_out);

} /* end of ldra_qq_tbrun_output */

static void ldra_qq_file_tc_init_code ()
{
/*
 * File based test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 */
} /* end of ldra_qq_file_tc_init_code */

static void ldra_qq_file_tc_cleanup_code ()
{
/*
 * File based test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 */
} /* end of ldra_qq_file_tc_cleanup_code */

/*
 *
 * Procedure to execute test case 1
 * Procedure to execute existing test case 1
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : initialise_customer
 *
 */
int ldra_qq_execute_test_case_1 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 1 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 1
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit favourite;
  double cash;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 1;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 1;
  ldra_qq_procedure_name = "initialise_customer";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 1 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: initialise_customer\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 1 3 1 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input parameter applied through local - favourite
 */
  favourite = apple;
  printf (" Input for favourite = apple \n");
  ldra_qq_tbrun_output ("I V Z favourite\n");
  ldra_qq_tbrun_output ("E apple\n");

/*
 * Assign Input parameter applied through local - cash
 */
  cash = 4.67;
  printf (" Input for cash = 4.67 \n");
  ldra_qq_tbrun_output ("I V Z cash\n");
  ldra_qq_tbrun_output ("E 4.67\n");

  printf ("\n Call initialise_customer\n");

/*
 * Call Procedure for Test Case
 */
    initialise_customer      (favourite,
       cash);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_fruit (apple,customer.favourite,"customer.favourite",
                          "apple",'H',1,1,
                          1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.favourite is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.favourite\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_fruit (pear,customer.cheapest,"customer.cheapest",
                          "pear",'H',1,1,
                          1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cheapest is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cheapest\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (4.670000,customer.cash,"customer.cash",
                           "4.670000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -2;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 1 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_1 */

/*
 *
 * Procedure to execute test case 2
 * Procedure to execute existing test case 2
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : customer_cash_injection
 *
 */
int ldra_qq_execute_test_case_2 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 2 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 2
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  double injection;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 2;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 2;
  ldra_qq_procedure_name = "customer_cash_injection";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 2 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: customer_cash_injection\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 2 3 2 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input parameter applied through local - injection
 */
  injection = 0.02;
  printf (" Input for injection = 0.02 \n");
  ldra_qq_tbrun_output ("I V Z injection\n");
  ldra_qq_tbrun_output ("E 0.02\n");

  printf ("\n Call customer_cash_injection\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc2_return = customer_cash_injection
      (injection);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (4.690000,customer.cash,"customer.cash",
                           "4.690000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (4.690000,tbrun_qq_tc2_return,"%%",
                           "4.690000",'O',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -3;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 2 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_2 */

/*
 *
 * Procedure to execute test case 3
 * Procedure to execute existing test case 3
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : get_number_of_pence
 *
 */
int ldra_qq_execute_test_case_3 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 3 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 3
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  double price;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 3;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 3;
  ldra_qq_procedure_name = "get_number_of_pence";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 3 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: get_number_of_pence\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 3 3 3 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input parameter applied through local - price
 */
  price = customer.cash;
  printf (" Input for price = customer.cash \n");
  ldra_qq_tbrun_output ("I V Z price\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

  printf ("\n Call get_number_of_pence\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc3_return = get_number_of_pence
      (price);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (469,tbrun_qq_tc3_return,"%%",
                        "469",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -4;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 3 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_3 */

/*
 *
 * Procedure to execute test case 4
 * Procedure to execute existing test case 4
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : convert_pence
 *
 */
int ldra_qq_execute_test_case_4 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 4 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 4
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  int pence;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 4;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 4;
  ldra_qq_procedure_name = "convert_pence";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 4 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: convert_pence\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 4 3 4 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - us_dollar_er
 */
  us_dollar_er = us_dollar_er;
  printf (" Input for us_dollar_er = us_dollar_er \n");
  ldra_qq_tbrun_output ("I V G us_dollar_er\n");
  ldra_qq_tbrun_output ("E us_dollar_er\n");

/*
 * Assign Input parameter applied through local - pence
 */
  pence = tbrun_qq_tc3_return;
  printf (" Input for pence = tbrun_qq_tc3_return \n");
  ldra_qq_tbrun_output ("I V Z pence\n");
  ldra_qq_tbrun_output ("E tbrun_qq_tc3_return\n");

  printf ("\n Call convert_pence\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc4_return = convert_pence
      (pence);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (7.196805,tbrun_qq_tc4_return,"%%",
                           "7.196805",'O',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -5;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 4 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_4 */

/*
 *
 * Procedure to execute test case 5
 * Procedure to execute existing test case 5
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit
 *
 */
int ldra_qq_execute_test_case_5 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 5 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 5
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 5;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 5;
  ldra_qq_procedure_name = "buy_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 5 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 5 3 5 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = grapes;
  printf (" Input for name = grapes \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E grapes\n");

  printf ("\n Call buy_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc5_return = buy_fruit
      (name);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (4.380000,customer.cash,"customer.cash",
                           "4.380000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc5_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -6;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 5 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_5 */

/*
 *
 * Procedure to execute test case 6
 * Procedure to execute existing test case 6
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit
 *
 */
int ldra_qq_execute_test_case_6 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 6 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 6
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 6;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 5;
  ldra_qq_procedure_name = "buy_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 6 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 6 3 5 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = orange;
  printf (" Input for name = orange \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E orange\n");

  printf ("\n Call buy_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc6_return = buy_fruit
      (name);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (4.240000,customer.cash,"customer.cash",
                           "4.240000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc6_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -7;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 6 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_6 */

/*
 *
 * Procedure to execute test case 7
 * Procedure to execute existing test case 7
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit
 *
 */
int ldra_qq_execute_test_case_7 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 7 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 7
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 7;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 5;
  ldra_qq_procedure_name = "buy_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 7 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 7 3 5 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = melon;
  printf (" Input for name = melon \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E melon\n");

  printf ("\n Call buy_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc7_return = buy_fruit
      (name);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (3.380000,customer.cash,"customer.cash",
                           "3.380000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc7_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -8;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 7 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_7 */

/*
 *
 * Procedure to execute test case 8
 * Procedure to execute existing test case 8
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit_ex
 *
 */
int ldra_qq_execute_test_case_8 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 8 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 8
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  char first_char;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 8;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 7;
  ldra_qq_procedure_name = "buy_fruit_ex";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 8 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit_ex\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 8 3 7 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - first_char
 */
  first_char = 'a';
  printf (" Input for first_char = 'a' \n");
  ldra_qq_tbrun_output ("I V Z first_char\n");
  ldra_qq_tbrun_output ("E 'a'\n");

  printf ("\n Call buy_fruit_ex\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc8_return = buy_fruit_ex
      (first_char);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (3.260000,customer.cash,"customer.cash",
                           "3.260000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc8_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -9;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 8 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_8 */

/*
 *
 * Procedure to execute test case 9
 * Procedure to execute existing test case 9
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit_ex
 *
 */
int ldra_qq_execute_test_case_9 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 9 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 9
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  char first_char;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 9;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 7;
  ldra_qq_procedure_name = "buy_fruit_ex";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 9 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit_ex\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 9 3 7 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - first_char
 */
  first_char = 'p';
  printf (" Input for first_char = 'p' \n");
  ldra_qq_tbrun_output ("I V Z first_char\n");
  ldra_qq_tbrun_output ("E 'p'\n");

  printf ("\n Call buy_fruit_ex\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc9_return = buy_fruit_ex
      (first_char);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (3.170000,customer.cash,"customer.cash",
                           "3.170000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc9_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -10;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 9 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_9 */

/*
 *
 * Procedure to execute test case 10
 * Procedure to execute existing test case 10
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : change_fruit_price
 *
 */
int ldra_qq_execute_test_case_10 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 10 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 10
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;
  double increment;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 10;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 8;
  ldra_qq_procedure_name = "change_fruit_price";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 10 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: change_fruit_price\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 10 3 8 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = apple;
  printf (" Input for name = apple \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E apple\n");

/*
 * Assign Input parameter applied through local - increment
 */
  increment = 0.01;
  printf (" Input for increment = 0.01 \n");
  ldra_qq_tbrun_output ("I V Z increment\n");
  ldra_qq_tbrun_output ("E 0.01\n");

  printf ("\n Call change_fruit_price\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc10_return = change_fruit_price
      (name,
       increment);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.130000,fruit_prices[0],"fruit_prices[0]",
                           "0.130000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for fruit_prices[0] is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H fruit_prices[0]\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.140000,fruit_prices[1],"fruit_prices[1]",
                           "0.140000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for fruit_prices[1] is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H fruit_prices[1]\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.310000,fruit_prices[2],"fruit_prices[2]",
                           "0.310000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for fruit_prices[2] is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H fruit_prices[2]\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.090000,fruit_prices[3],"fruit_prices[3]",
                           "0.090000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for fruit_prices[3] is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H fruit_prices[3]\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.860000,fruit_prices[4],"fruit_prices[4]",
                           "0.860000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for fruit_prices[4] is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H fruit_prices[4]\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.130000,tbrun_qq_tc10_return,"%%",
                           "0.130000",'O',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -11;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 10 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_10 */

/*
 *
 * Procedure to execute test case 11
 * Procedure to execute existing test case 11
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : calculate_cheapest_fruit
 *
 */
int ldra_qq_execute_test_case_11 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 11 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 11
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 11;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 9;
  ldra_qq_procedure_name = "calculate_cheapest_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 11 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: calculate_cheapest_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 11 3 9 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

  printf ("\n Call calculate_cheapest_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc11_return = calculate_cheapest_fruit
      ();

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_fruit (pear,tbrun_qq_tc11_return,"%%",
                          "pear",'O',1,1,
                          1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -12;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 11 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_11 */

/*
 *
 * Procedure to execute test case 12
 * Procedure to execute existing test case 12
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_fruit
 *
 */
int ldra_qq_execute_test_case_12 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 12 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 12
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 12;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 5;
  ldra_qq_procedure_name = "buy_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 12 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 12 3 5 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = tbrun_qq_tc11_return;
  printf (" Input for name = tbrun_qq_tc11_return \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E tbrun_qq_tc11_return\n");

  printf ("\n Call buy_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc12_return = buy_fruit
      (name);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (3.080000,customer.cash,"customer.cash",
                           "3.080000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc12_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -13;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 12 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_12 */

/*
 *
 * Procedure to execute test case 13
 * Procedure to execute existing test case 13
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : fruit_cheaper_than
 *
 */
int ldra_qq_execute_test_case_13 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 13 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 13
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  fruit name;
  double price;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 13;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 10;
  ldra_qq_procedure_name = "fruit_cheaper_than";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 13 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: fruit_cheaper_than\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 13 3 10 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - name
 */
  name = apple;
  printf (" Input for name = apple \n");
  ldra_qq_tbrun_output ("I V Z name\n");
  ldra_qq_tbrun_output ("E apple\n");

/*
 * Assign Input parameter applied through local - price
 */
  price = 0.05;
  printf (" Input for price = 0.05 \n");
  ldra_qq_tbrun_output ("I V Z price\n");
  ldra_qq_tbrun_output ("E 0.05\n");

  printf ("\n Call fruit_cheaper_than\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc13_return = fruit_cheaper_than
      (name,
       price);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (0,tbrun_qq_tc13_return,"%%",
                        "0",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -14;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 13 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_13 */

/*
 *
 * Procedure to execute test case 14
 * Procedure to execute existing test case 14
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : get_favourite_fruit_price
 *
 */
int ldra_qq_execute_test_case_14 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 14 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 14
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  struct customer_info * buyer;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 14;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 12;
  ldra_qq_procedure_name = "get_favourite_fruit_price";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 14 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: get_favourite_fruit_price\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 14 3 12 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - buyer
 */
  buyer = &customer;
  printf (" Input for buyer = &customer \n");
  ldra_qq_tbrun_output ("I V Z buyer\n");
  ldra_qq_tbrun_output ("E &customer\n");

  printf ("\n Call get_favourite_fruit_price\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc14_return = get_favourite_fruit_price
      (buyer);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.130000,tbrun_qq_tc14_return,"%%",
                           "0.130000",'O',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -15;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 14 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_14 */

/*
 *
 * Procedure to execute test case 15
 * Procedure to execute existing test case 15
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : how_many_favourite_fruit
 *
 */
int ldra_qq_execute_test_case_15 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 15 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 15
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 15;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 13;
  ldra_qq_procedure_name = "how_many_favourite_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 15 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: how_many_favourite_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 15 3 13 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input global - customer.favourite
 */
  customer.favourite = customer.favourite;
  printf (" Input for customer.favourite = customer.favourite \n");
  ldra_qq_tbrun_output ("I V G customer.favourite\n");
  ldra_qq_tbrun_output ("E customer.favourite\n");

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

  printf ("\n Call how_many_favourite_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc15_return = how_many_favourite_fruit
      ();

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (23,tbrun_qq_tc15_return,"%%",
                        "23",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -16;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 15 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_15 */

/*
 *
 * Procedure to execute test case 16
 * Procedure to execute existing test case 16
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : write_price_list
 *
 */
int ldra_qq_execute_test_case_16 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 16 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 16
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  FILE * fp;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 16;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 14;
  ldra_qq_procedure_name = "write_price_list";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 16 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: write_price_list\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 16 3 14 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_names[0]
 */
  fruit_names[0] = fruit_names[0];
  printf (" Input for fruit_names[0] = fruit_names[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_names[0]\n");
  ldra_qq_tbrun_output ("E fruit_names[0]\n");

/*
 * Assign Input global - fruit_names[1]
 */
  fruit_names[1] = fruit_names[1];
  printf (" Input for fruit_names[1] = fruit_names[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_names[1]\n");
  ldra_qq_tbrun_output ("E fruit_names[1]\n");

/*
 * Assign Input global - fruit_names[2]
 */
  fruit_names[2] = fruit_names[2];
  printf (" Input for fruit_names[2] = fruit_names[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_names[2]\n");
  ldra_qq_tbrun_output ("E fruit_names[2]\n");

/*
 * Assign Input global - fruit_names[3]
 */
  fruit_names[3] = fruit_names[3];
  printf (" Input for fruit_names[3] = fruit_names[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_names[3]\n");
  ldra_qq_tbrun_output ("E fruit_names[3]\n");

/*
 * Assign Input global - fruit_names[4]
 */
  fruit_names[4] = fruit_names[4];
  printf (" Input for fruit_names[4] = fruit_names[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_names[4]\n");
  ldra_qq_tbrun_output ("E fruit_names[4]\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - fp
 */
  fp = fopen ("ggrocers.txt","w");
  printf (" Input for fp = fopen (\"ggrocers.txt\",\"w\") \n");
  ldra_qq_tbrun_output ("I V Z fp\n");
  ldra_qq_tbrun_output ("E fopen (\"ggrocers.txt\",\"w\")\n");

  printf ("\n Call write_price_list\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc16_return = write_price_list
      (fp);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (1.530000,tbrun_qq_tc16_return,"%%",
                           "1.530000",'O',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -17;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 16 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_16 */

/*
 *
 * Procedure to execute test case 17
 * Procedure to execute existing test case 17
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_healthiest
 *
 */
int ldra_qq_execute_test_case_17 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 17 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 17
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  int amount;
  int most;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 17;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 15;
  ldra_qq_procedure_name = "buy_healthiest";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 17 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_healthiest\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 17 3 15 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Global pointer initialisation - health
 */
  health = NULL;
  printf (" Input for health = NULL \n");
  ldra_qq_tbrun_output ("I V Q health\n");
  ldra_qq_tbrun_output ("E NULL\n");

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - amount
 */
  amount = 5;
  printf (" Input for amount = 5 \n");
  ldra_qq_tbrun_output ("I V Z amount\n");
  ldra_qq_tbrun_output ("E 5\n");

/*
 * Assign Input parameter applied through local - most
 */
  most = TRUE;
  printf (" Input for most = TRUE \n");
  ldra_qq_tbrun_output ("I V Z most\n");
  ldra_qq_tbrun_output ("E TRUE\n");

  printf ("\n Call buy_healthiest\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc17_return = buy_healthiest
      (amount,
       most);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  ldra_qq_variable_converted = 1;
  ldra_qq_variable_passed = 1;
  ldra_qq_var_exception_raised = 0;
  printf (" Output for health is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H health\n");

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.500000,customer.cash,"customer.cash",
                           "0.500000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (2,tbrun_qq_tc17_return,"%%",
                        "2",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -18;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 17 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_17 */

/*
 *
 * Procedure to execute test case 18
 * Procedure to execute existing test case 18
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : buy_healthiest
 *
 */
int ldra_qq_execute_test_case_18 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 18 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 18
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  int amount;
  int most;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 18;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 15;
  ldra_qq_procedure_name = "buy_healthiest";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 18 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: buy_healthiest\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 18 3 15 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Global pointer initialisation - health
 */
  health = NULL;
  printf (" Input for health = NULL \n");
  ldra_qq_tbrun_output ("I V Q health\n");
  ldra_qq_tbrun_output ("E NULL\n");

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input parameter applied through local - amount
 */
  amount = 3;
  printf (" Input for amount = 3 \n");
  ldra_qq_tbrun_output ("I V Z amount\n");
  ldra_qq_tbrun_output ("E 3\n");

/*
 * Assign Input parameter applied through local - most
 */
  most = FALSE;
  printf (" Input for most = FALSE \n");
  ldra_qq_tbrun_output ("I V Z most\n");
  ldra_qq_tbrun_output ("E FALSE\n");

  printf ("\n Call buy_healthiest\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc18_return = buy_healthiest
      (amount,
       most);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output global for harness
 */
  ldra_qq_variable_converted = 1;
  ldra_qq_variable_passed = 1;
  ldra_qq_var_exception_raised = 0;
  printf (" Output for health is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H health\n");

/*
 * check Output global for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_double (0.230000,customer.cash,"customer.cash",
                           "0.230000",'H',1,1,
                           1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Output for customer.cash is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X H customer.cash\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (0,tbrun_qq_tc18_return,"%%",
                        "0",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -19;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 18 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_18 */

/*
 *
 * Procedure to execute test case 19
 * Procedure to execute existing test case 19
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : char_to_fruit
 *
 */
int ldra_qq_execute_test_case_19 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 19 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 19
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */
  char first_char;
  fruit * name;

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 19;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 6;
  ldra_qq_procedure_name = "char_to_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 19 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: char_to_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 19 3 6 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input parameter applied through local - first_char
 */
  first_char = 'g';
  printf (" Input for first_char = 'g' \n");
  ldra_qq_tbrun_output ("I V Z first_char\n");
  ldra_qq_tbrun_output ("E 'g'\n");

/*
 * Assign Parameter pointer initialisation - name
 */
  name = &customer.favourite;
  printf (" Input for name = &customer.favourite \n");
  ldra_qq_tbrun_output ("I V P name\n");
  ldra_qq_tbrun_output ("E &customer.favourite\n");

  printf ("\n Call char_to_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc19_return = char_to_fruit
      (first_char,
       name);

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Output parameter for harness
 */
  ldra_qq_variable_converted = 1;
  ldra_qq_variable_passed = 1;
  ldra_qq_var_exception_raised = 0;
  printf (" Output for name is *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O name\n");

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (1,tbrun_qq_tc19_return,"%%",
                        "1",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -20;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 19 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_19 */

/*
 *
 * Procedure to execute test case 20
 * Procedure to execute existing test case 20
 * File for test case : D:\LDRA_Workarea_CEE_9.4.6\Ggrocers.c
 * Procedure for test case : how_many_favourite_fruit
 *
 */
int ldra_qq_execute_test_case_20 ()
{
#ifdef _MSC_VER
#pragma message (" => Test Case 20 started")
#endif

  int ldra_qq_test_case_passed = 1;
  int ldra_qq_no_exception_raised = 1;
  int ldra_qq_variable_converted = 1;
  int ldra_qq_variable_passed = 1;
  int ldra_qq_var_exception_raised = 0;
/*
 * Declarations for test case 20
 */
/*
 * Test case declaration code will be placed here
 * Variables declared in this section have local scope to the test case function
 */

  ldra_qq_last_test_case = 0;
  ldra_qq_test_case_number = 20;
  ldra_qq_module_number = 3;
  ldra_qq_module_name = "D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c";
  ldra_qq_procedure_number = 13;
  ldra_qq_procedure_name = "how_many_favourite_fruit";
  ldra_qq_in_existing_test_case = 1;
  ldra_qq_in_new_test_case = 0;
  ldra_qq_action_code = "";

  printf ("\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n*\n");
  printf ("* Executing Existing Test Case 20 in Sequence Ggrocers\n");
  printf ("* File	: D:\\LDRA_Workarea_CEE_9.4.6\\Ggrocers.c\n");
  printf ("* Procedure	: how_many_favourite_fruit\n");
  printf ("*\n");
  printf ("****************************************");
  printf ("****************************************");
  printf ("\n");
  ldra_qq_tbrun_output ("T 20 3 13 0 V\n");
/*
 * Test case initialisation code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */

/*
 * Assign Input global - fruit_prices[0]
 */
  fruit_prices[0] = fruit_prices[0];
  printf (" Input for fruit_prices[0] = fruit_prices[0] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[0]\n");
  ldra_qq_tbrun_output ("E fruit_prices[0]\n");

/*
 * Assign Input global - fruit_prices[1]
 */
  fruit_prices[1] = fruit_prices[1];
  printf (" Input for fruit_prices[1] = fruit_prices[1] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[1]\n");
  ldra_qq_tbrun_output ("E fruit_prices[1]\n");

/*
 * Assign Input global - fruit_prices[2]
 */
  fruit_prices[2] = fruit_prices[2];
  printf (" Input for fruit_prices[2] = fruit_prices[2] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[2]\n");
  ldra_qq_tbrun_output ("E fruit_prices[2]\n");

/*
 * Assign Input global - fruit_prices[3]
 */
  fruit_prices[3] = fruit_prices[3];
  printf (" Input for fruit_prices[3] = fruit_prices[3] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[3]\n");
  ldra_qq_tbrun_output ("E fruit_prices[3]\n");

/*
 * Assign Input global - fruit_prices[4]
 */
  fruit_prices[4] = fruit_prices[4];
  printf (" Input for fruit_prices[4] = fruit_prices[4] \n");
  ldra_qq_tbrun_output ("I V G fruit_prices[4]\n");
  ldra_qq_tbrun_output ("E fruit_prices[4]\n");

/*
 * Assign Input global - customer.favourite
 */
  customer.favourite = customer.favourite;
  printf (" Input for customer.favourite = customer.favourite \n");
  ldra_qq_tbrun_output ("I V G customer.favourite\n");
  ldra_qq_tbrun_output ("E customer.favourite\n");

/*
 * Assign Input global - customer.cash
 */
  customer.cash = customer.cash;
  printf (" Input for customer.cash = customer.cash \n");
  ldra_qq_tbrun_output ("I V G customer.cash\n");
  ldra_qq_tbrun_output ("E customer.cash\n");

  printf ("\n Call how_many_favourite_fruit\n");

/*
 * Call Procedure for Test Case
 */
    tbrun_qq_tc20_return = how_many_favourite_fruit
      ();

  if (ldra_qq_no_exception_raised == 1)
  {
    printf (" No exception raised\n");
    ldra_qq_tbrun_output ("C V\n");
  }
  else
  {
    printf (" Exception raised\n");
    ldra_qq_tbrun_output ("C E\n");
  }

/*
 * check Function result for harness
 */
  if (ldra_qq_no_exception_raised == 1)
  {
  if (ldra_qq_dtop_int (0,tbrun_qq_tc20_return,"%%",
                        "0",'O',1,1,
                        1,"") == 0)
  {
    ldra_qq_test_case_passed = 0;
  }
  }
  else
  {
  printf (" Function Result:  *** Suspended *** \n");
  ldra_qq_tbrun_output ("O X O %%%%\n");
  }

/*
 * Test case cleanup code will be placed here
 * Variables declared in this section do not have global scope
 * Some compilers may not allow declarations here
 */
  ldra_qq_tbrun_output ("D\n\n");

  ldra_qq_last_test_case = -21;
  ldra_qq_test_case_number = 0;
  ldra_qq_tc_iterator = -1;
  ldra_qq_tc_repeater = -1;
  ldra_qq_module_number = 0;
  ldra_qq_module_name = NULL;
  ldra_qq_procedure_number = 0;
  ldra_qq_procedure_name = NULL;
  ldra_qq_in_existing_test_case = 0;
  ldra_qq_action_code = "";

#ifdef _MSC_VER
#pragma message (" => Test Case 20 finished")
#endif

  return ldra_qq_test_case_passed;
} /* end of ldra_qq_execute_test_case_20 */

/* ****11 Entry-Point routine start */
#if defined(QQQBITMAP)
#if defined(QQQstructbitmap)
#define QQQtbruninitbitmap
#endif
#endif

#if defined(QQQtbruninitbitmap)
  int tbrun_qqqinitialise ()
  {
    qqqqinitialise(0);
    return 0;
  }
#endif

void main ()
{
#if defined(QQQtbruninitbitmap)
  int tbrun_qqq_init = tbrun_qqqinitialise();
#endif

  int ldra_qq_fail_count = 0;

  ldra_qq_sequence_init ();

  if (ldra_qq_etc_initialisation ())
  {
/*
 * Execute existing test cases
 */
    if (ldra_qq_execute_test_case_1 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_2 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_3 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_4 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_5 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_6 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_7 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_8 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_9 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_10 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_11 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_12 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_13 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_14 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_15 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_16 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_17 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_18 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_19 () == 0)
    {
      ldra_qq_fail_count++;
    }

    if (ldra_qq_execute_test_case_20 () == 0)
    {
      ldra_qq_fail_count++;
    }

    ldra_qq_etc_completion ();

    printf ("\n\n TBrun has executed 20 Test Cases\n");
    if (ldra_qq_fail_count > 0)
    {
      printf ("\n *** There were %d Failures ***\n\n",ldra_qq_fail_count);
    }
    else
    {
      printf (" All these tests passed\n\n");
    }
  }

  ldra_qq_sequence_cleanup ();

/* ****12 Entry-Point routine end */

#if defined(QQQCOMPRESSED_EXH)
#if defined QQQMAINFL
  Ggrocers_3zzdump();
#endif
#endif
#if defined ldra_qq_terminate_main
#if defined(QQQBITMAP)
  qqqupload ();
#endif
#if defined _INC_STDIO || defined _STDIO_H
  fflush (stdout);
#endif
  _fcloseall ();
#if defined _WIN32
  _exit (0);
#else
  exit (0);
#endif
#endif

} /* end of main */

